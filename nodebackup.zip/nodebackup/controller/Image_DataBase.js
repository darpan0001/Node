const createConnection = require('../database/MySqlWorkbench');
const multer = require('multer');
const path = require('path');

// Set up multer for file upload
const imageStorage = multer.diskStorage({
    destination: 'imageStore',
    filename: (req, file, cb) => {
        cb(null, file.fieldname + '_' + Date.now() + path.extname(file.originalname));
    }
});

const imageUpload = multer({
    storage: imageStorage,
    limits: {
        fileSize: 1000000 // 1 MB
    },
    fileFilter(req, file, cb) {
        if (!file.originalname.match(/\.(png|jpg)$/)) {
            return cb(new Error('Please upload an image'));
        }
        cb(null, true);
    }
});

// Function to handle Single Image file upload and database insert
const singleImageUpload = async (req, res) => {
    let connection;
    try {
        if (!req.file) {
            return res.status(400).send({ error: 'No file uploaded' });
        }

        const imagePath = req.file.path; // Get the path of the uploaded image

        connection = await createConnection(); // Establish the database connection

        // SQL query to insert a new record with the image path
        const query = 'INSERT INTO students (image_path) VALUES (?)';
        const [result] = await connection.execute(query, [imagePath]);

        res.send({
            message: 'File uploaded and saved to database successfully',
            imagePath: imagePath
        });
    } catch (error) {
        console.error('Error during image upload:', error);
        res.status(500).send({ error: 'An error occurred while uploading the image.' });
    } finally {
        if (connection) {
            await connection.end(); // Ensure the connection is closed
        }
    }
};








// Function to handle Multiple Image file upload and database insert
const multipleImageUpload = async (req, res) => {
    let connection;
    try {
        if (!req.files || !req.body.keys) {
            return res.status(400).send({ error: 'No files or keys provided' });
        }

        const keys = req.body.keys; // Array of keys passed in the request body
        const files = req.files;    // Array of uploaded files

        connection = await createConnection(); // Establish the database connection

        // Loop through the keys array and corresponding files
        for (let i = 0; i < keys.length; i++) {
            const file = files[i];
            if (file) {
                const imagePath = file.path;
                const query = 'INSERT INTO user_images (image_key, image_path) VALUES (?, ?)';
                await connection.execute(query, [keys[i], imagePath]);
            }
        }

        res.send('Files uploaded and saved to database successfully');
    } catch (error) {
        // Handle multer-specific errors
        if (error instanceof multer.MulterError) {
            res.status(400).send({ error: `Multer error: ${error.message}` });
        } else {
            // Handle other errors
            console.error('Error during image upload:', error);
            res.status(500).send({ error: 'An error occurred while uploading the images.' });
        }
    } finally {
        if (connection) {
            await connection.end(); // Ensure the connection is closed
        }
    }
};

module.exports = {
    imageUpload,
    singleImageUpload, 
    multipleImageUpload
};
