const multer = require('multer');
const path = require('path');

// Set up multer for image storage
const imageStorage = multer.diskStorage({
    destination: 'imageStore', // Directory where images will be stored
    filename: (req, file, cb) => {
        cb(null, file.fieldname + '_' + Date.now() + path.extname(file.originalname));
    }
});

// Configure multer
const imageUpload = multer({
    storage: imageStorage,
    limits: {
        fileSize: 1000000 // Limit file size to 1 MB
    },
    fileFilter(req, file, cb) {
        if (!file.originalname.match(/\.(png|jpg)$/)) {
            return cb(new Error('Please upload a PNG or JPG image'));
        }
        cb(null, true);
    }
});


module.exports= {imageUpload}