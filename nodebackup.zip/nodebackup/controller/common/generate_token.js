var jwt = require('jsonwebtoken');
const secretKey="darpan#123"


function generateToken(userDetail)
{
   const coupon= jwt.sign
   ({
        data: userDetail
        }, secretKey, { expiresIn: '1h' 

    });

    return coupon
}

module.exports=generateToken 