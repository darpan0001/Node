var jwt = require('jsonwebtoken');
const secretKey="darpan#123";

function verifyToken(token)
{
    var verifiedToken = "";
    jwt.verify(token, secretKey, function(err, decoded) 
    {
        console.log(decoded) // bar
        verifiedToken = decoded
    });
    return verifiedToken
}


module.exports=verifyToken 