const dbConnect = require('../database/db');

const ejsData = (req, res) => 
{
    let data = 
    { 
        name: 'Akashdeep', 
        hobbies: ['playing football', 'playing chess', 'cycling'] 
    }
    res.render('index',{ data: data })
}



const ejsMongoData = async (req, res) => 
{
    let db = await dbConnect()
    const collection = db.collection('employeeListData');
    const findResult = await collection.find({}).toArray();
    res.render('index2',{ data: findResult})

}

module.exports={ejsData, ejsMongoData}