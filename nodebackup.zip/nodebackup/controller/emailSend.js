
var nodemailer = require('nodemailer');

const emailData=(req,res)=>
{
  var transporter = nodemailer.createTransport
  ({

    service: 'gmail',
    auth:
    {
      user: 'darpanmehta0001@gmail.com',
      pass: 'mdydaqjpipwpqrxp'
    }

  });
      
  var mailOptions = 
  {
    from: 'darpanmehta0001@gmail.com',
    to: 'rekhakhurana84@gmail.com',
    subject: 'Sending Email using Node.js',
    text: 'Hi Rekha I am Darpan this side'
  };
      
  transporter.sendMail(mailOptions, function(error, info)
  {
    if (error) 
    {
      console.log(error);
    } 
    else 
    {
      console.log('Email sent: ' + info.response);
    }

  });

  res.send("you have successfully register, detail send on your email")
}




const postEmailData= async(req,res)=>
{
  var transporter = nodemailer.createTransport
  ({
    service: 'gmail',
    auth: 
    {
      user: 'darpanmehta0001@gmail.com',
      pass: 'mdydaqjpipwpqrxp'
    }
  });

  console.log(req.body)

  var mailOptions = 
  {
    from: 'darpanmehta0001@gmail.com',
    to: req.body.email,
    subject: 'Sending Email using Node.js',
    text: 'Hi I am Darpan this side'
  };
          
  transporter.sendMail(mailOptions, function(error, info)
  {
    if (error) 
    {
      console.log(error);
    } 
    else 
    {
      console.log('Email sent: ' + info.response);
    }
  });

  res.send("you have successfully register, detail send on your email")
}
    

module.exports=
{
  emailData, postEmailData
};