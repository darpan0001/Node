//In this we are using nodemailer to send to the email that is receiving from postman.
var nodemailer = require('nodemailer');
const postEmailData= async(req,res)=>{
    var transporter = nodemailer.createTransport({
        service: 'gmail',
        auth: {
          user: 'darpanmehta0001@gmail.com',
          pass: 'mdydaqjpipwpqrxp'
        }
      });
      console.log(req.body)
      var mailOptions = {
        from: 'darpanmehta0001@gmail.com',
        to: req.body.email,
        subject: 'Sending Email using Node.js',
       text: 'Hi I am Darpan this side'
      };
      
      transporter.sendMail(mailOptions, function(error, info){
        if (error) {
          console.log(error);
        } else {
          console.log('Email sent: ' + info.response);
        }
      });
      res.send("you have successfully register, detail send on your email")}

      module.exports={
        postEmailData
    };