//In this we are using fs module to write read and update txt file.
const fs = require('fs');


const writeEmpList=(req,res)=>
{
  content = JSON.stringify
  ([
    {"Name":"Darpan 1"},
    {"Name":"Vinod"},
    {"Name":"Ayan"}
  ])

  fs.writeFile('employee1.txt', content, 'utf-8', function(err, data) 
  {
    if (err) throw err;
    res.send('File Created Sucessfully');
  })
}



const readEmpList=(req,res)=>
{
  fs.readFile('employee1.txt','utf-8', function(err, data) 
  {
    if (err) throw err;
    res.send(data);
  })
}


const appendEmpList=(req,res)=>
{
  fs.appendFile('employee1.txt','Hey there this is Darpan Mehta I was posted as J.E in Irrigationa $ Water Resources Department, Sirsa','utf-8', function(err, data) 
  {
    if (err) throw err;
    res.send('File updated successfully');
  })
}


module.exports={
    writeEmpList, readEmpList, appendEmpList
};