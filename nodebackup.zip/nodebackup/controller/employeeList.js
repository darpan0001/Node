//In this workspace we are receiving data from postman to mongodb and we applied token in it.
var jwt = require('jsonwebtoken');
const dbConnect = require('../database/db');
const generateToken=require('./common/generate_token')
const verifyToken=require('./common/verifyToken')


//..................................
//Fetching Data from Mongo Db
//..................................

const getEmployeeList = async (req, res) => 
{
    try 
    {
        let db = await dbConnect()
        const collection = db.collection('employeeListData');
        const findResult = await collection.find({}).toArray();
        console.log(findResult)
        res.send(findResult)
    }
    catch (error)
    {
        console.error("Error in getEmployeeList: ", error);
        res.status(500).send
        ({
            "status": 500,
            "message": "Internal Server Error"
        });
    }
}

const insertEmployee = async (req, res) => 
{
    try
    {
        if (!req.body || Object.keys(req.body).length === 0) 
        {
            return res.send
            ({
                "status": 400,
                "message": "No record entered"
            });
        }
        let db = await dbConnect()
        const collection = db.collection('employeeListData');
           
        const insertResult = await collection.insertOne(req.body)
        if (insertResult.acknowledged == true) 
        {
            res.send
            ({
                "status": 200,
                "message": "record is inserted successfully",
                "id": insertResult.insertedId
            })
        }
        else 
        {
            res.send
            ({
                "status": 400,
                "message": "something wrong",
            })
        }
    }
    catch (error)
    {
        console.error("Error in insertEmployee: ", error);
        res.status(500).send
        ({
            "status": 500,
            "message": "Internal Server Error"
        });
    }
}




// const insertEmployee = async (req, res) => 
// {
//     try
//     {     
//         let db = await dbConnect()
//         const collection = db.collection('employeeListData');
//         var token=req.body.token;
//         var datadecode=""
       
//         datadecode=await verifyToken(token)
//         if(datadecode!=null)
//         {
//             const insertResult = await collection.insertOne(req.body)
//             if (insertResult.acknowledged == true) 
//             {
//                 res.send
//                 ({
//                     "status": 200,
//                     "message": "record is inserted successfully",
//                     "id": insertResult.insertedId
//                 })
//             }
//             else 
//             {
//                 res.send
//                 ({
//                     "status": 400,
//                     "message": "something wrong",
//                 })
//             }
//         }
//         else
//         {
//             res.send
//             ({
//                 status:400,
//                 message:"token is expired or invalid"
//             }) 
    
//         }
//     }
//     catch (error)
//     {
//         console.error("Error in insertEmployee: ", error);
//         res.status(500).send
//         ({
//             "status": 500,
//             "message": "Internal Server Error"
//         });
//     }
// }




// const removeEmployee = async (req, res) => 
// {
//     try
//     {
//         let db = await dbConnect()
//         const collection = db.collection('employeeListData');
//         // const findResult = await collection.find({}).toArray();
//         // console.log(findResult)
//         // res.send(findResult)
//         console.log(req.query.name)
//         const deleteResult = await collection.deleteOne({name:req.query.name}); //http://localhost:8080/deleteemployees?name=Vinod
//         //const deleteResult = await collection.deleteOne({name:"Naman"});
//         console.log(deleteResult)
//         res.send('data deleted sucessfully' + deleteResult);
//     }
//     catch (error)
//     {
//         console.error("Error in removeEmployee: ", error);
//         res.status(500).send
//         ({
//             "status": 500,
//             "message": "Internal Server Error"
//         });
//     }
// }



const removeEmployee = async (req, res) => 
{
    try 
    {
        if (!req.query.name) 
        {
            return res.status(400).send
            ({
                "status": 400,
                "message": "name is required"
            });
        }
        let db = await dbConnect();
        const collection = db.collection('employeelist');

        const deleteResult = await collection.deleteOne({ name: req.query.name });

        if (deleteResult.deletedCount === 0) 
        {
            return res.status(404).send
            ({
                "status": 404,
                "message": `Employee with name ${req.query.name} not found`
            });
        }
        else
        {
            console.log(deleteResult);
            res.send
            ({
                "status": 200,
                "message": "Data deleted successfully",
                "result": deleteResult
            });
        } 
    }
    catch (error) 
    {
        console.error("Error in removeEmployee: ", error);
        res.status(500).send
        ({
            "status": 500,
            "message": "Internal Server Error"
        });
    }
};



// const updateEmployee = async (req, res) => 
// {
//     try
//     {
//         let db = await dbConnect()
//         const collection = db.collection('employeelist');
//         // const updatedResult = await collection.updateOne({name:"Darpan"},{ $set: { name:"DarpanMehta"}});
//         const updatedResult = await collection.updateOne({name:req.query.name},{$set:req.body}); //http://localhost:8080/updateemployees?name=Darpan kumar
//         console.log(updatedResult)
//         res.send('data updated sucessfully');
//     }
//     catch (error)
//     {
//         console.error("Error in insertFindEmployee: ", error);
//         res.status(500).send
//         ({
//             "status": 500,
//             "message": "Internal Server Error"
//         });
//     }
// }


const updateEmployee = async (req, res) => 
{
    try 
    {
        if (!req.query.name) 
        {
            return res.status(400).send
            ({
                "status": 400,
                "message": "name is required"
            });
        }

        else if (!req.body || Object.keys(req.body).length === 0) 
        {
            return res.status(400).send
            ({
                "status": 400,
                "message": "Bad Request: Update data is required in the request body"
            });
        }

        let db = await dbConnect();
        const collection = db.collection('employeelist');

        const updatedResult = await collection.updateOne({ name: req.query.name }, { $set: req.body });

        if (updatedResult.matchedCount === 0) 
        {
            return res.status(404).send
            ({
                "status": 404,
                "message": `Employee with name ${req.query.name} not found`
            });
        }

        console.log(updatedResult);
        res.send
        ({
            "status": 200,
            "message": "Data updated successfully",
            "result": updatedResult
        });
    } 
    catch (error) 
    {
        console.error("Error in updateEmployee: ", error);
        res.status(500).send
        ({
            "status": 500,
            "message": "Internal Server Error"
        });
    }
};





const insertFindEmployee = async (req, res) => 
{
    try 
    {
        let db = await dbConnect()
        const collection = db.collection('employeeListData');
        const existingEmployee = await collection.find({name: req.body.name}).toArray();
        console.log(existingEmployee)
        if (existingEmployee.length>1) 
            {
                const token=await generateToken(req.body)
                res.status(200).send
                ({
                    "status": 200,
                    "message": "Login Successfull",
                    "token":token
                });
            }
     else
        {
            res.send
            ({
            "status": 400,
            "message": "invalid login",
            });
            
            // const insertResult = await collection.insertOne(req.body);
            // if (insertResult.acknowledged == true) 
            // {
            //     res.send
            //     ({
            //         "status": 200,
            //         "message": "record is inserted successfully",
            //         "id": insertResult.insertedId
            //     });
            // }
        }
       
    }
    catch (error)
    {
        console.error("Error in insertFindEmployee: ", error);
        res.status(500).send
        ({
            "status": 500,
            "message": "Internal Server Error"
        });
    }
};


module.exports = {
    getEmployeeList, insertEmployee, removeEmployee, updateEmployee, insertFindEmployee 
}