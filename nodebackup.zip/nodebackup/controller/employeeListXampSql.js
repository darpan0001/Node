//These functions are used in mysql thorugh xamp

const dbConnectsql = require('../database/PostgreSQLdb');
const generateToken=require('./common/generate_token')
const verifyToken=require('./common/verifyToken')


const getEmployeeListInSql = async (req, res) =>
{
  try
  {
    dbConnectsql.query('select * from employees',function(err,result,fields) 
    {
      if(err) 
      {
        console.log(err)
        res.send
        ({
          status:400,
          message:err
        })
      }
      else
      {
        console.log(result)  ;
        res.send
        ({
          status:200,
          message:result
        }) 
      }
    })
  }
  catch (error)
  {
    console.error("Error in getEmployeeListbysql: ", error);
    res.status(500).send
    ({
      "status": 500,
      "message": "Internal Server Error"
    });
  }
}




const findEmployeeByPostmanInSql = (req, res) => 
{
  try 
  {
    // Get the employee details from the request body
    const { first_name, last_name, age } = req.body;
  
    // Build the query to find employees based on provided fields
    const selectQuery = `
    SELECT * FROM employees 
    WHERE first_name = ? AND last_name = ? AND age = ?
    `;
  
    // Execute the select query
    dbConnectsql.query(selectQuery, [first_name, last_name, age], async (err, rows) => 
    {
      if (err) 
      {
        console.error("Error finding employee:", err);
        res.status(500).send
        ({
          status: 500,
          message: "Internal Server Error"
        });
      }
      else
      { 
        if(rows.length>0)
        {
          const token=await generateToken(req.body)
          res.status(200).send
          ({
            "status": 200,
            "message": "Login Successfull",
            "token":token
          });
        }
      else
       {
        res.status(200).send
        ({
          "status": 400,
          "message": "Login invalid",
           
        });
       }
      }
    });
  }
  catch (error) 
  {
    console.error("Error in findEmployeeByPostmanInSql:", error);
    res.status(400).send
    ({
      status: 400,
      message: error.message
    });
  }
};



const createTableAndInsertRows = (req, res) => 
{
  try
  {
    // Check if the table already exists
    const checkTableQuery = "SHOW TABLES LIKE 'employees'";

    dbConnectsql.query(checkTableQuery, (err, result) => 
    {
      if (err) 
      {
        console.error('Error checking table existence:', err);
        res.status(500).send('Error checking table existence.');
        return;
      }
      if (result.length > 0) 
      {
        console.log('Table already exists.');
        res.send('Table already exists.');
        return;
      }

    // Table does not exist, so create it
    const createTableQuery = `CREATE TABLE employees 
    (
      id INT AUTO_INCREMENT PRIMARY KEY,
      first_name VARCHAR(50),
      last_name VARCHAR(50),
      age INT
    );`;

    dbConnectsql.query(createTableQuery, (err, result) => 
    {
      if (err) 
      {
        console.error('Error creating table:', err);
        res.status(500).send('Error creating table.');
        return;
      }
      else
      {
        console.log('Table created.');
        res.send('Table created.');
      }
    });
  });
  }
  catch (error) 
  {
    console.error("Error in createTableAndInsertRows:", error);
    res.status(400).send
    ({
      status: 400,
      message: error.message
    });
  }
};






//inserting multiple data statically.
const insertDataInSql = (req, res) => 
{ 
  try
  { 
    // Query to insert multiple rows
    const insertQuery = `INSERT INTO employees (first_name, last_name, age) VALUES ?;`;
  
    // Values to be inserted
    const values = 
    [
      ['Darpan', 'Mehta', 29],
      ['Vinod', 'Mehta', 32],
      ['Navdeep', 'Mehta', 36],
      ['Ayan', 'Mehta', 12],
      ['Aadi', 'Mehta', 15]
    ];
      
    // Executing the query
    dbConnectsql.query(insertQuery, [values], (err, rows) => 
    {
      if (err) throw err;
      console.log("All Rows Inserted");
      res.send("All Rows Inserted");
    });
  }
  catch (error)
  {
    console.error("Error in insertDataInSql: ", error);
    res.status(500).send
    ({
      "status": 500,
      "message": "Internal Server Error"
    });
  }
};




//inserting multiple data from postman with token.               
const insertPostmanDataInSql = async (req, res) => 
{ 
  try
  { 
    // Query to insert multiple rows
    const insertQuery = `INSERT INTO employees (first_name, last_name, age) VALUES ?;`;
    
    //Value to be inserted from postman
    const values = req.body.values
    console.log("Received data from Postman:", values);

    const token=req.body.token
    console.log("Token received:", token);
    
    var datadecode=""
    datadecode= await verifyToken(token)
    console.log("datadecode:", datadecode);
    
    if(datadecode!=null)
    {
      console.log("Token is valid:", datadecode);
      // Executing the query
      dbConnectsql.query (insertQuery, [values], (err, rows) => 
      {
        if (err) 
        { 
          throw err;
        }
        else
        {
          console.log("All Rows Inserted");
          res.send("All Rows Inserted");
        }
      });
    }
    else
    {
      res.send
      ({
        status:400,
        message:"token is expired or invalid"
      }) 
    }
  }
  catch (error)
  {
    console.error("Error in createPostTableAndInsertRows: ", error);
    res.status(500).send
    ({
      "status": 500,
      "message": "Internal Server Error"
    });
  }
};



//inserting multiple data from postman without token.  
const insertPostmanDataInSql2 = (req, res) => 
{ 
  try
  { 
    // Query to insert multiple rows
    const insertQuery = `INSERT INTO employees (first_name, last_name, age) VALUES ?;`;
      
    //Value to be inserted from postman
    const values = req.body
    console.log("Received data from Postman2:", values);
  
    // Executing the query
    dbConnectsql.query (insertQuery, [values], (err, rows) => 
    {
      if (err) 
      { 
        throw err;
      }
      else
      {
        console.log("All Rows Inserted");
        res.send("All Rows Inserted");
      }
    });  
  }  
  catch (error)
  {
    console.error("Error in insertPostmanDataInSql2: ", error);
    res.status(500).send
    ({
      "status": 500,
      "message": "Internal Server Error"
    });
  }
};
  



//updating multiple data statically.
const updateDataInSql = (req, res) => 
{    
  // Query to update multiple rows
  const updateQuery = `
   UPDATE employees 
    SET first_name = 'Vinod'
    WHERE age = 35
  `;
           
  // Executing the query
  dbConnectsql.query(updateQuery, (err, rows) => 
    {
      if (err) throw err;
      else 
      console.log("Record Updated Successfully");
      res.send("Record Updated Successfully");
    });
};




//updating multiple data dynamically from postman.
const updateDataInSqlByPostman = (req, res) => 
{
  try
  { 
    let updateQuery = `
    UPDATE employees SET
    first_name = ?
    WHERE age = 32`;

    // Values to be updated from postman
    const {first_name}  = req.body;

    // const updateValues= [];
    // if (first_name)
    // {
    //   updateQuery += 'first_name = ?,';
    //   updateValues.push(first_name)
    // }

    // if (last_name)
    // {
    //   updateQuery += 'last_name = ?,';
    //   updateValues.push(last_name)
    // }

    // if (age)
    // {
    //   updateQuery += 'age = ?,';
    //   updateValues.push(age)
    // }

    // // Log the received data to check if it's correct
    // console.log('Received data:', { first_name, last_name, age });

    // Executing the query
    dbConnectsql.query(updateQuery, first_name, (err, rows) => 
    {
      if (err) throw err;
      else 
      console.log("Record Updated Successfully");
      res.send("Record Updated Successfully");
    });
  }
  catch (error)
  {
    console.error("Error in updatePostTable: ", error);
    res.status(500).send
    ({
      "status": 500,
      "message": "Internal Server Error"
    });
  }
};


//Deleting employee with postman
const deleteEmployeeByPostmanInSql = (req, res) => 
{
  try 
  {
    // Get the employee name to delete from the request body
    const { first_name, last_name, age } = req.body;

    // Query to delete employee by name
    const deleteQuery = `DELETE FROM employees WHERE age = 12`;

    // Execute the delete query
    dbConnectsql.query(deleteQuery, [first_name, last_name, age], (err, result) => 
    {
      if (err) 
      {
        console.error("Error deleting employee:", err);
        res.status(500).send
        ({
          status: 500,
          message: "Internal Server Error"
        });
      }
      else
      {
        console.log("Employee(s) deleted successfully");
        res.send("Employee(s) deleted successfully");
      }
    });
  }
  catch (error) 
  {
    console.error("Error in deleteEmployeeByName:", error);
    res.status(400).send
    ({
      status: 400,
      message: error.message
    });
  }
};



//Deleting data statically.
const deleteEmployeeInSql = (req, res) => 
{
  try
  {
    // Query to delete multiple rows
    const deleteQuery = `
    DELETE FROM employees 
    WHERE age = 25
    `;
           
    // Executing the query
    dbConnectsql.query(deleteQuery, (err, rows) => 
    {
      if (err) throw err;
      else 
      {
        console.log("Record(s) Deleted Successfully");
        res.send("Record(s) Deleted Successfully");
      }
    });
  }
  catch (error)
  {
    console.error("Error in deleteEmployeeStatically: ", error);
    res.status(500).send
    ({
      "status": 500,
      "message": "Internal Server Error"
    });
  }
};

 
module.exports=
{
  getEmployeeListInSql, findEmployeeByPostmanInSql, createTableAndInsertRows, insertDataInSql, insertPostmanDataInSql, insertPostmanDataInSql2, updateDataInSql, updateDataInSqlByPostman, deleteEmployeeByPostmanInSql, deleteEmployeeInSql
}