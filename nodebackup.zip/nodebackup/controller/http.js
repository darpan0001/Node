//In this we are using http module to create server.
const http = require('http');
const server = http.createServer ((req, res) => 
    {
        res.write('Hare Krishan'); // Write a response to the client
        res.end(); // End the response
    });

    module.exports = server;