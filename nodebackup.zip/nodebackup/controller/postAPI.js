//In this we are using fs module to write and read file.
const fs=require ('fs')

const postApiwrite=(req,res)=>
{
    content = 'Hey There i am Darpan Mehta from Sirsa trying to learn Node.js'
    fs.writeFile('PostAPI.txt',content,'utf-8', function(err, data) 
    {
        if (err) throw err;
        res.send('File Created successfully');
    })
}


const postApiread=(req,res)=>
{       
    fs.readFile('PostAPI.txt','utf-8', function(err, data) 
    {
        if (err) throw err;
        res.send(data);
    })
}



//In this we are updating student txt data receiving from postman.
const postApiappend=(req,res)=>
{    
    fs.appendFile('student.txt',JSON.stringify(req.body), function(err, data) 
    {
        if (err) throw err;
        res.send(req.body,);
    })
}


module.exports=
{
    postApiwrite, postApiread, postApiappend
}
   
    