const createConnection = require('../../database/MySqlWorkbench');
const generateToken=require('../common/generate_token')
const verifyToken=require('../common/verifyToken')

//........................................
//Fetch Data from Sql Database.
//........................................

const dataFromWorkBench = async (req, res) => 
{
  let connection;
  try 
  {
    connection = await createConnection(); // Establish the connection
    console.log('Database Connected');
      
    const [result] = await connection.query('SELECT * FROM sys.teachers');
    await connection.end(); // Close the connection
  
    res.json(result); // Send the results as JSON
  } 
  catch (err) 
  {
    console.error('Error fetching data:', err);
    res.status(500).send(err.message); // Handle any errors
  }
};

//........................................
//Find employee in Sql Database.
//........................................

const findEmpSql = async (req, res) => 
{
  let connection;
  try 
  {    
    connection = await createConnection(); // Establish the connection
    console.log('Database Connected');
    
    const { Username, Password } = req.body; // Extract data from request body
    console.log('Request Data:', { Username, Password });

    const [result] =  await connection.query(
      'SELECT * FROM sys.login WHERE Username=? AND Password=?',
      [Username, Password],
      
    );

  console.log('Querry result', result)

    await connection.end(); 
  
    if (result.length > 0)
    {
      const token=await generateToken(req.body)
      res.status(200).send
      ({
        "status": 200,
        "message": "Login Successfull",
        "token":token
      });
    }
    else
    {
      res.status(200).send
      ({
        "status": 400,
        "message": "Login invalid",
      });
    }
  }
  catch (error) 
  {
    console.error("Error in findEmployeeByPostmanInSql:", error);
    res.status(400).send
    ({
      status: 400,
      message: error.message
    });
  }
};

//.....................................
//Insert Statically Data to Sql Database.
//.....................................

const insertStaticData = async (req, res) => {
  let connection;
  try {
    connection = await createConnection(); // Establish the connection
    console.log('Database Connected');
    
    // Create table if it doesn't exist
    const createTableQuery = `
      CREATE TABLE IF NOT EXISTS sys.teachers 
      (
        id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(255) NOT NULL,
        course VARCHAR(255) NOT NULL,
        email VARCHAR(255) NOT NULL 
      );
    `;
    await connection.query(createTableQuery);
    console.log('Table created or already exists');

    // Static data to be inserted
    const staticData = 
    [
      { name: 'Vinod', course: 'mongo', email: 'Vinod@gmail.com' }
     
    ];

    // Insert each record into the database
    for (const data of staticData) 
    {
      const query = 'INSERT INTO sys.mehta (name, course, email) VALUES (?, ?, ?)';
      const values = [data.name, data.course, data.email];
        
      const [result] = await connection.query(query, values); // Execute insert query
      console.log(`Inserted record with ID: ${result.insertId}`); // Log the inserted ID
    }

    await connection.end(); // Close the connection

    res.status(201).json({ message: 'Static data inserted successfully' }); // Send a response
  } 
  catch (err) 
  {
    console.error('Error inserting data:', err);
    res.status(500).send(err.message); // Handle any errors
  }
};


//.....................................
//Insert single dynamic Data to Sql Database from postman.
//.....................................

const insertTeacherData = async (req, res) => 
{
  let connection;
  try {
    connection = await createConnection();
    console.log('Database Connected');

    const createTableQuery = `
      CREATE TABLE IF NOT EXISTS teachers 
      (
         id INT AUTO_INCREMENT PRIMARY KEY,
        first_name VARCHAR(255) NOT NULL,
        last_name VARCHAR(255) NOT NULL,
        subject VARCHAR(255) NOT NULL,
        email VARCHAR(255) NOT NULL UNIQUE
       
      );
    `;
    await connection.query(createTableQuery);
    console.log('Table created or already exists');

    const { first_name, last_name, subject, email, token } = req.body;
    console.log(first_name, last_name, subject, email)

    // const token=req.body.token
    console.log("Token received:", token);

    var datadecode=""
    datadecode= await verifyToken(token)
    console.log("datadecode:", datadecode);

    if(datadecode!=null)
    {
      const query = 'INSERT INTO teachers (first_name, last_name, subject, email) VALUES (?, ?, ?, ?)';
      await connection.query(query, [first_name, last_name, subject, email]);

      res.send
      ([{ 
        message: 'Data added successfully',
        status:200
      }]);
    }
    else
    {
      res.send
      ({
        status:400,
        message:"token is expired or invalid"
      }) 
    }
  } 
  catch (err) 
  {
    console.error('Error:', err);
    res.status(500).json({ error: 'Database error' });
  } 
  finally 
  {
    if (connection) 
    {
      await connection.end();
      console.log('Database connection closed');
    }
  }
};


//.....................................
//Insert single dynamic Data with Img to Sql Database from postman.
//.....................................

const insertTeachersDataImg = async (req, res) => {
  
  let connection;
  try {
      if (!req.file) {
          return res.status(400).send({ error: 'No file uploaded' });
      }

      const imagePath = req.file.path; // Get the path of the uploaded image
      console.log(imagePath)
      const { first_name, last_name, subject, email, token } = req.body;
      console.log(token)
      connection = await createConnection(); // Establish the database connection

      // SQL query to insert teacher data along with the image path
      const query = 'INSERT INTO teachers (first_name, last_name, subject, email, image_path) VALUES (?, ?, ?, ?, ?)';
      const [result] = await connection.execute(query, [first_name, last_name, subject, email, imagePath]);

      res.status(200).send({
          status: 200,
          id: result.insertId,
          image_path: imagePath
      });
  } catch (error) {
      console.error('Error during image upload and data insertion:', error);
      res.status(500).send({ error: 'An error occurred while uploading the image and adding student data.' });
  } finally {
      if (connection) {
          await connection.end(); // Ensure the connection is closed
      }
  }
};

//.....................................
//Insert mutiple dynamic Data to Sql Database from postman.
//.....................................

const insertMultipleDynamicData = async (req, res) => 
{
  let connection;
  try {
    connection = await createConnection();
    console.log('Database Connected');

    const createTableQuery = `
      CREATE TABLE IF NOT EXISTS students 
      (
        id INT AUTO_INCREMENT PRIMARY KEY,
        first_name VARCHAR(255) NOT NULL,
        last_name VARCHAR(255) NOT NULL,
        course VARCHAR(255) NOT NULL,
        email VARCHAR(255) NOT NULL UNIQUE
      );
    `;
    await connection.query(createTableQuery);
    console.log('Table created or already exists');

    const students = req.body;
    console.log('Students:', students);

    if (!Array.isArray(students) || students.length === 0) 
    {
      return res.status(400).json({ message: 'No students data provided' });
    }

    const values = students.map(student => 
    [
      student.first_name,
      student.last_name,
      student.course,
      student.email,
    ]);

    const query = 'INSERT INTO students (first_name, last_name, course, email) VALUES ?';
    await connection.query(query, [values]);

    res.status(201).json({ message: 'Students added successfully' });
  } 
  catch (err) 
  {
    console.error('Error:', err);
    res.status(500).json({ error: 'Database error' });
  } 
  finally 
  {
    if (connection) 
    {
      await connection.end();
      console.log('Database connection closed');
    }
  }
};

//.....................................
//Delete Complete Individual from postman using id.
//.....................................

const deleteTeachersData = async (req, res) => 
{
  let connection;
  try 
  {
    console.log('Request received');
    connection = await createConnection();
    console.log('Database Connected');

    console.log('Request params:', req.params); // Log entire params object
    const { id } = req.params; // Extracting id from request parameters
    console.log('ID to delete:', id); // Log extracted id

    if (!id) 
    {
      return res.status(400).json({ error: 'ID is required' });
    }

    const token=req.body.token
    console.log("Token received:", token);

    var datadecode=""
    datadecode= await verifyToken(token)
    console.log("datadecode:", datadecode);

    if(datadecode!=null)
    {

      const query = 'DELETE FROM teachers WHERE id = ?';
      const [result] = await connection.query(query, [id]);

      if (result.affectedRows > 0) 
      {
        res.status(200).json({ message: 'Data deleted successfully' });
      } 
      else 
      {
        res.status(404).json({ message: 'Data not found' });
      }
    }
    else
    {
      res.send
      ({
        status:400,
        message:"token is expired or invalid"
      }) 
    }
  } 
  catch (err) 
  {
    console.error('Error:', err);
    res.status(500).json({ error: 'Database error' });
  } 
  finally 
  {
    if (connection) 
    {
      await connection.end();
      console.log('Database connection closed');
    }
  }
};

//.....................................
//Update Individual from postman using id.
//.....................................

const updateData = async (req, res) => 
{
  let connection;
  try 
  {
    console.log('Request received');
    connection = await createConnection();
    console.log('Database Connected');
  
    console.log('Request params:', req.params); // Log entire params object
    const { id } = req.params; // Extracting id from request parameters
    console.log('ID to update:', id); // Log extracted id
  
    const { first_name, last_name, course, email } = req.body; // Extract data from request body
    console.log('Data to update:', { first_name, last_name, course, email }); // Log data to update
  
    if (!id) 
    {
      return res.status(400).json({ error: 'ID is required' });
    }
  
    if (!first_name || !last_name || !course || !email) 
    {
      return res.status(400).json({ error: 'All fields are required' });
    }

    const token=req.body.token
    console.log("Token received:", token);

    var datadecode=""
    datadecode= await verifyToken(token)
    console.log("datadecode:", datadecode);

    if(datadecode!=null)
    {
      const query = 'UPDATE students SET first_name = ?, last_name = ?, course = ?, email = ? WHERE id = ?';
      const [result] = await connection.query(query, [first_name, last_name, course, email, id]);
  
      if (result.affectedRows > 0) 
      {
        res.status(200).json({ message: 'Data updated successfully' });
      } 
      else 
      {
        res.status(404).json({ message: 'Data not found' });
      }
    }
    else
    {
      res.send
      ({
        status:400,
        message:"token is expired or invalid"
      }) 
    }
  } 
  catch (err) 
  {
    console.error('Error:', err);
    res.status(500).json({ error: 'Database error' });
  } 
  finally 
  {
    if (connection) 
    {
      await connection.end();
      console.log('Database connection closed');
    }
  }
};


//.....................................
//Update Individual data with image from postman using id.
//.....................................

const updateDataWithImg = async (req, res) => {
  let connection;
  try {
    console.log('Request received');
    connection = await createConnection();
    console.log('Database Connected');
  
    console.log('Request params:', req.params); // Log entire params object
    const { id } = req.params; // Extracting id from request parameters
    console.log('ID to update:', id); // Log extracted id
  
    const { first_name, last_name, subject, email, token } = req.body; // Extract data from request body
    console.log('Data to update:', { first_name, last_name, subject, email }); // Log data to update
  
    if (!id) {
      return res.status(400).json({ error: 'ID is required' });
    }
  
    if (!first_name || !last_name || !subject || !email) {
      return res.status(400).json({ error: 'All fields are required' });
    }

    console.log("Token received:", token);
    const datadecode = await verifyToken(token);
    console.log("datadecode:", datadecode);

    if (datadecode != null) {
      let imagePath;
      if (req.file) {
        imagePath = req.file.path; // Get the path of the uploaded image
        console.log('Image uploaded:', imagePath);
        
        // You can add image processing here if needed, e.g., resizing or converting formats
      }

      const query = imagePath 
        ? 'UPDATE students SET first_name = ?, last_name = ?, subject = ?, email = ?, image_path = ? WHERE id = ?' 
        : 'UPDATE students SET first_name = ?, last_name = ?, subject = ?, email = ? WHERE id = ?';

      const params = imagePath 
        ? [first_name, last_name, subject, email, imagePath, id] 
        : [first_name, last_name, subject, email, id];

      const [result] = await connection.query(query, params);
  
      if (result.affectedRows > 0) {
        res.status(200).json({ message: 'Data updated successfully', image_path: imagePath });
      } else {
        res.status(404).json({ message: 'Data not found' });
      }
    } else {
      res.status(400).json({ message: "Token is expired or invalid" });
    }
  } catch (err) {
    console.error('Error:', err);
    res.status(500).json({ error: 'Database error' });
  } finally {
    if (connection) {
      await connection.end();
      console.log('Database connection closed');
    }
  }
};



  

module.exports = 
{  
  dataFromWorkBench,
  findEmpSql,
  insertStaticData,
  insertTeacherData,
  insertTeachersDataImg,
  insertMultipleDynamicData, 
  deleteTeachersData, 
  updateData,
  updateDataWithImg
};