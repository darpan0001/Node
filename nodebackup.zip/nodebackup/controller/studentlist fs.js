//In this we are using fs module to create, read and update txt file.
const fs = require('fs')


const writeStudentList=(req,res)=>
{
    fs.writeFile('student.txt','Hey There i am Darpan Mehta from Sirsa trying to learn Node.js','utf-8', function(err, data) 
    {
        if (err) throw err;
        res.send('File Created successfully');
    })
}

const readStudentList=(req,res)=>
{
    fs.readFile('student.txt','utf-8', function(err, data) 
    {
        if (err) throw err;
        res.send(data);
    })
}

const appendStudentList=(req,res)=>
{
    fs.appendFile('student.txt','Working past as a JE in Irrigation','utf-8', function(err, data) 
    {
        if (err) throw err;
        res.send('File updated successfully');
    })
}


module.exports=
{
    writeStudentList, readStudentList, appendStudentList
}