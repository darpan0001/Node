//In this we are using url module to find host pathname and search of any url.
var url = require('url');


function urlhost()
{
const adr = 'localhost:8080/default.htm?year=2017&month=february';
const q = url.parse(adr, true);
console.log(q.host);
}

function urlpathname()
{
const adr = 'localhost:8080/default.htm?year=2017&month=february';
const q = url.parse(adr, true);
console.log(q.pathname);
}

function urlsearch()
{
const adr = 'localhost:8080/default.htm?year=2017&month=february';
const q = url.parse(adr, true);
console.log(q.search);
var k = q.query; //returns an object: { year: 2017, month: 'february' }
console.log(k.month);
}

function urlquerry()
{
const adr = 'localhost:8080/default.htm?year=2017&month=february';
const q = url.parse(adr, true);
var k = q.query; //returns an object: { year: 2017, month: 'february' }
console.log(k.month);
}

module.exports=
{
    urlhost, urlpathname, urlsearch, urlquerry
}