const mysql = require('mysql2/promise'); // Use promise-based API for simplicity with async/await

async function createConnection () 
{
  try 
  {
    const connection = await mysql.createConnection
    ({
      host: 'localhost',
      user: 'root',
      password: 'Password@123',
      database: 'sys'
    });
    console.log('Connected to Database');
    
    return connection;
  } 
  catch (error) 
  {
    console.error('Error Connecting to Database:', error);
    throw error;
  }
};

module.exports =  createConnection;