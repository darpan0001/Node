//This workspace is used to deploy the data on netlify server. 
//1st step netlify init 2nd netlify deploy 3rd netlify deploy --prod


 const express = require('express')
 const serverless = require("serverless-http");
 
 
 const app = express();
 const router = express.Router();
 const indexRouter=require('../router/index')

 app.use(express.json());//to understand the json file receiving from postman

 router.get("/", (req, res) => {
        res.send("App is running..");
});
 router.use('/',indexRouter);


app.use("/.netlify/functions/app", router);
module.exports.handler = serverless(app);

// server.listen(8080, () => {
//     console.log(`Server running on port 8080`);
// });
