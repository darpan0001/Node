const express = require('express');
const router = express.Router();
const importfs=require('../controller/employee fs')
const postapi=require('../controller/postAPI')
const urlhost=require('../controller/urlhost')
const email=require('../controller/emailSend')
const exportEmp=require('../controller/employeeList')
const ejsData=require('../controller/ejs')
const studentAPI=require('../controller/sql workbench/students_data')
const {imageUpload}=require('../controller/common/Image_Upload')
const teachersAPI=require('../controller/sql workbench/teacher_data')
// const {imageUpload, singleImageUpload, multipleImageUpload}=require('../controller/Image_DataBase')

router.get('/',(req,res)=>
{
    res.send("welcome to node js express api ")
})

router.get('/writeempdata', importfs.writeEmpList)    
router.get('/readempdata', importfs.readEmpList)
router.get('/appendempdata', importfs.appendEmpList)

router.get('/emailsend', email.emailData)
router.post('/postEmailSend', email.postEmailData)

router.get('/urlhost', urlhost.urlhost)
router.get('/urlpathname', urlhost.urlpathname)
router.get('/urlquerry', urlhost.urlquerry)
router.get('/urlsearch', urlhost.urlsearch)

router.post('/writepostapi', postapi.postApiwrite)
router.post('/readpostapi', postapi.postApiread)
router.post('/appendpostapi', postapi.postApiappend)

router.get("/getemployees",exportEmp.getEmployeeList)
router.post("/insertemployees",exportEmp.insertEmployee)
router.post("/insertFindemployees",exportEmp.insertFindEmployee)
router.delete("/deleteemployees",exportEmp.removeEmployee)
router.put("/updateemployees",exportEmp.updateEmployee)

router.get("/home",ejsData.ejsData)
router.get("/mongohome",ejsData.ejsMongoData)

router.get("/getEmployeeSqlWorkbench",studentAPI.dataFromWorkBench)
router.post("/findEmpSql",studentAPI.findEmpSql)
router.post("/insertSingleDynamicSqlData",imageUpload.single('image'),studentAPI.insertStudentsDataImg)
router.delete("/deleteIndividualSqlData/:id",studentAPI.deleteData)
// router.put("/updateSqlData/:id",studentAPI.updateData)
router.put("/updateSqlData/:id",imageUpload.single('image'),studentAPI.updateDataWithImg)

router.get("/getTeachersData",teachersAPI.dataFromWorkBench)
router.post("/insertTeachersData",teachersAPI.insertTeacherData)
router.post("/insertTeachersData",imageUpload.single('image'),teachersAPI.insertTeachersDataImg)
router.delete("/deleteTeachersData/:id",teachersAPI.deleteTeachersData)

// router.post('/singleImageUpload', imageUpload.single('file'), singleImageUpload) 
// router.post('/multipleImageUpload', imageUpload.array('file'), multipleImageUpload) 

router.get('**',(req,res)=>
{
    res.send("you have entered wrong route, please provide right one ")
})

module.exports=router;